class Course {

}